import pandas as pd
import numpy as np
from latticex.psi_c._psi import LogLevel, PSITYPE, PSIConfig, __IOHandler, __PSIHandler
# print(LogLevel)
# print(PSITYPE)
# print(PSIConfig)
# print(__IOHandler)


class IOHandler(__IOHandler):
    def __init__(self) -> None:
        super().__init__()

    def create_io(self, task_id, node_id, cfg):
        return super().create_io(task_id, node_id, cfg)

    def release_io(self, taskid=""):
        return super().release_io(taskid)


class PSIHandler(__PSIHandler):
    """0-ALICE;1-BOB"""

    def __init__(self) -> None:
        super().__init__()

    def set_loglevel(self, loglevel: int or LogLevel):
        super().set_loglevel(int(loglevel))

    def get_perf_stats(self, pretty, taskid=""):
        return super().get_perf_stats(pretty, taskid)

    def activate(self, name, taskid=""):
        return super().activate(name, taskid)

    def deactivate(self, taskid=""):
        return super().deactivate(taskid)

    def prepare(self, inputs, **kwargs):
        """
        inputs list/array/file
        kwargs: delim, taskid
        """
        delim = kwargs['delim'] if 'delim' in kwargs else ','
        taskid = kwargs['taskid'] if 'taskid' in kwargs else ''
        return super()._prepare(inputs, delim, taskid)

    def run(self, inputs, outputs, **kwargs):
        delim = kwargs['delim'] if 'delim' in kwargs else ','
        taskid = kwargs['taskid'] if 'taskid' in kwargs else ''
        return super()._run(inputs, outputs, delim,  taskid)

    def __get_numpy(self, file, *args, **kwargs):
        if not isinstance(file, str):
            return file

        arr = None
        try:
            df = pd.read_csv(file, *args, **kwargs)
            arr = df.to_numpy()
        except Exception:
            pass
            # print(e)
        return arr
